from PIL import Image
import os
import glob

files = glob.glob('assets/*removebg-preview.png')
for f in files:
    img = Image.open(f).convert('RGBA')
    # Resize using LANCZOS or BOX for high quality downsampling
    img_small = img.resize((16, 16), Image.Resampling.LANCZOS)
    
    # Threshold it to make it crisp pixel art again!
    pixels = img_small.load()
    for y in range(16):
        for x in range(16):
            r, g, b, a = pixels[x, y]
            if a > 64:
                pixels[x, y] = (255, 255, 255, 255)
            else:
                pixels[x, y] = (0, 0, 0, 0)
    
    img_small.save(f)
    print(f'Processed {f}')
