import json
code = ""
for filename in ['C:/Users/shima/.gemini/antigravity-ide/brain/c432181d-6f94-4f3d-ba55-6b525e1d85a4/.system_generated/logs/transcript_full.jsonl']:
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line)
            idx = data.get('step_index', 0)
            if idx > 1810:
                break
            
            if 'tool_calls' in data:
                for tc in data['tool_calls']:
                    if tc['name'] == 'write_to_file' and 'generate_blocks.py' in tc['args']['TargetFile']:
                        code = tc['args']['CodeContent']
                    elif tc['name'] == 'replace_file_content' and 'generate_blocks.py' in tc['args']['TargetFile']:
                        code = code.replace(tc['args']['TargetContent'], tc['args']['ReplacementContent'])
                    elif tc['name'] == 'multi_replace_file_content' and 'generate_blocks.py' in tc['args']['TargetFile']:
                        chunks = tc['args']['ReplacementChunks']
                        if isinstance(chunks, str):
                            chunks = json.loads(chunks)
                        for chunk in chunks:
                            code = code.replace(chunk['TargetContent'], chunk['ReplacementContent'])

print("FINAL CODE:")
print(code)
