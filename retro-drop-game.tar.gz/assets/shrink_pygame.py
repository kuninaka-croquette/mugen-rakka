import pygame
import os
import glob

pygame.init()
pygame.display.set_mode((1,1), pygame.HIDDEN)

files = glob.glob('assets/*removebg-preview.png')
for f in files:
    img = pygame.image.load(f).convert_alpha()
    
    # Smoothscale down to 16x16
    img_small = pygame.transform.smoothscale(img, (16, 16))
    
    # Threshold it to pure white and transparent
    for y in range(16):
        for x in range(16):
            r, g, b, a = img_small.get_at((x, y))
            if a > 64:
                img_small.set_at((x, y), (255, 255, 255, 255))
            else:
                img_small.set_at((x, y), (0, 0, 0, 0))
                
    pygame.image.save(img_small, f)
    print(f'Processed {f}')
