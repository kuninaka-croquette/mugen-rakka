import pygame
import random
import sys
import os
import json
import asyncio
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class DropManGame:
    def __init__(self):
        pygame.init()
        # 実際のウィンドウサイズ
        self.WINDOW_W = 600
        self.WINDOW_H = 800
        self.screen = pygame.display.set_mode((self.WINDOW_W, self.WINDOW_H))
        pygame.display.set_caption("無限落下")
        self.clock = pygame.time.Clock()

        # 内部の解像度（ガラケー仕様のQVGAサイズ）
        self.WIDTH = 240
        self.HEIGHT = 320
        self.display = pygame.Surface((self.WIDTH, self.HEIGHT))

        # 色
        self.WHITE = (255, 255, 255)
        self.BLACK = (0, 0, 0)
        self.GREEN = (0, 200, 0)
        self.RED = (255, 50, 50)
        self.CYAN = (0, 255, 255)

        # プレイヤー設定 (解像度に合わせて縮小)
        self.player_w = 16
        self.player_h = 16
        self.gravity = 0.1
        self.move_speed = 2.5

        # プラットフォーム設定
        self.PLAT_H = 6

        # 画像読み込み
        self.img_stand = self.load_img("standard-removebg-removebg-preview.png")
        self.img_left = self.load_img("left_run-removebg-removebg-preview.png")
        self.img_right = self.load_img("right_run-removebg-removebg-preview.png")
        self.img_fall = self.load_img("fall-removebg-removebg-preview.png")

        # 効果音読み込み
        try:
            self.snd_land = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "land.ogg"))
            self.snd_land.set_volume(0.15)
            self.snd_bounce = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "bounce.ogg"))
            self.snd_bounce.set_volume(0.2)
            self.snd_gameover = pygame.mixer.Sound(os.path.join(BASE_DIR, "assets", "gameover.ogg"))
            self.snd_gameover.set_volume(0.3)
        except Exception as e:
            print(f"Error loading sounds: {e}")
            self.snd_land = self.snd_bounce = self.snd_gameover = None

        # フォント読み込み (小さくする)
        font_path = os.path.join(BASE_DIR, "assets", "font.ttf")
        try:
            self.font = pygame.font.Font(font_path, 14)
            self.big_font = pygame.font.Font(font_path, 24)
        except Exception as e:
            print(f"Error loading font: {e}")
            self.font = pygame.font.SysFont(None, 14)
            self.big_font = pygame.font.SysFont(None, 24)

        # ランキング機能
        self.ranking_file = os.path.join(BASE_DIR, "ranking.json")
        self.load_ranking()

        # メニュー設定
        self.menu_options = ["スタート", "ランキング", "終了"]
        self.menu_index = 0

        self.game_state = "START"
        self.on_ground = False
        self.reset_game()
        self.game_state = "START"

    def load_img(self, name):
        path = os.path.join(BASE_DIR, "assets", name)
        try:
            img = pygame.image.load(path).convert_alpha()
            return pygame.transform.scale(img, (self.player_w, self.player_h))
        except Exception as e:
            print(f"Error loading {name} from {path}: {e}")
            surf = pygame.Surface((self.player_w, self.player_h))
            surf.fill(self.WHITE)
            return surf

    def load_ranking(self):
        if os.path.exists(self.ranking_file):
            try:
                with open(self.ranking_file, "r") as f:
                    self.ranking = json.load(f)
            except:
                self.ranking = []
        else:
            self.ranking = []

    def save_ranking(self):
        self.ranking.sort(reverse=True)
        self.ranking = self.ranking[:10]
        try:
            with open(self.ranking_file, "w") as f:
                json.dump(self.ranking, f)
        except Exception as e:
            print(f"Error saving ranking: {e}")

    def add_score(self):
        score_int = int(self.score)
        if score_int > 0:
            self.ranking.append(score_int)
            self.save_ranking()

    def reset_game(self):
        self.player_x = self.WIDTH // 2
        self.player_y = 50
        self.player_vy = 0
        self.player_vx = 0
        self.platforms = []
        self.scroll_speed = 0.4
        self.score = 0
        self.game_state = "PLAY"
        
        # 初期プラットフォーム
        self.platforms.append({
            "rect": pygame.Rect(self.WIDTH//2 - 20, 80, 40, self.PLAT_H),
            "type": "normal",
            "vx": 0,
            "exact_x": float(self.WIDTH//2 - 20),
            "exact_y": float(80)
        })
        for i in range(13):
            self.spawn_platform(100 + i * 20)

    def spawn_platform(self, y):
        w = random.randint(24, 56)
        x = random.randint(0, self.WIDTH - w)
        
        r = random.random()
        p_type = "normal"
        vx = 0
        if r < 0.2:
            p_type = "moving"
            vx = random.choice([-1.5, -1, 1, 1.5])
        elif r < 0.25:
            p_type = "trampoline"
            
        self.platforms.append({
            "rect": pygame.Rect(x, y, w, self.PLAT_H),
            "type": p_type,
            "vx": vx,
            "exact_x": float(x),
            "exact_y": float(y)
        })

    async def run(self):
        while True:
            self.handle_events()
            if self.game_state == "PLAY":
                self.update()
            self.draw()
            self.clock.tick(60)
            await asyncio.sleep(0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if self.game_state == "START":
                    if event.key == pygame.K_UP:
                        self.menu_index = (self.menu_index - 1) % len(self.menu_options)
                    elif event.key == pygame.K_DOWN:
                        self.menu_index = (self.menu_index + 1) % len(self.menu_options)
                    elif event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                        opt = self.menu_options[self.menu_index]
                        if opt == "スタート":
                            self.reset_game()
                        elif opt == "ランキング":
                            self.game_state = "RANKING"
                        elif opt == "終了":
                            pygame.quit()
                            sys.exit()
                elif self.game_state == "GAMEOVER":
                    if event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                        self.game_state = "START"
                elif self.game_state == "RANKING":
                    if event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
                        self.game_state = "START"

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.player_vx = -self.move_speed
        elif keys[pygame.K_RIGHT]:
            self.player_vx = self.move_speed
        else:
            self.player_vx = 0

        self.player_vy += self.gravity
        self.player_x += self.player_vx
        self.player_y += self.player_vy

        if self.player_x < 0: 
            self.player_x = 0
        if self.player_x > self.WIDTH - self.player_w: 
            self.player_x = self.WIDTH - self.player_w

        self.scroll_speed += 0.0005
        if self.scroll_speed > 2.2:
            self.scroll_speed = 2.2
        
        for p in self.platforms:
            p["exact_y"] -= self.scroll_speed
            p["rect"].y = int(p["exact_y"])
            if p["type"] == "moving":
                p["exact_x"] += p["vx"]
                p["rect"].x = int(p["exact_x"])
                if p["rect"].left < 0:
                    p["exact_x"] = 0
                    p["rect"].left = 0
                    p["vx"] *= -1
                elif p["rect"].right > self.WIDTH:
                    p["rect"].right = self.WIDTH
                    p["exact_x"] = self.WIDTH - p["rect"].width
                    p["vx"] *= -1

        player_rect = pygame.Rect(int(self.player_x), int(self.player_y), self.player_w, self.player_h + 2)
        self.on_ground = False
        
        for p in self.platforms:
            r = p["rect"]
            if self.player_vy > 0 and player_rect.colliderect(r) and player_rect.bottom <= r.top + 10:
                if p["type"] == "trampoline":
                    if getattr(self, 'snd_bounce', None): self.snd_bounce.play()
                    self.player_y = r.top - self.player_h
                    self.player_vy = -3.5
                    self.on_ground = False
                else:
                    if self.player_vy > 0.5 and getattr(self, 'snd_land', None): 
                        self.snd_land.play()
                    self.player_y = r.top - self.player_h
                    self.player_vy = 0
                    self.player_y -= self.scroll_speed
                    if p["type"] == "moving":
                        self.player_x += p["vx"]
                    self.on_ground = True
                break

        self.platforms = [p for p in self.platforms if p["rect"].bottom > 18] # ヘッダーに隠れたら消す
        
        if len(self.platforms) == 0 or self.platforms[-1]["rect"].y < self.HEIGHT - 20:
            self.spawn_platform(self.HEIGHT + random.randint(4, 12))

        self.score += self.scroll_speed * 0.1

        # 画面下、または上部のヘッダー(y=18)に接触したらゲームオーバー
        if self.player_y > self.HEIGHT or self.player_y <= 18:
            if self.game_state != "GAMEOVER":
                if getattr(self, 'snd_gameover', None): self.snd_gameover.play()
            self.game_state = "GAMEOVER"
            self.add_score()

    def draw_retro_block(self, rect, base_color):
        pygame.draw.rect(self.display, base_color, rect)
        light = (min(255, base_color[0]+70), min(255, base_color[1]+70), min(255, base_color[2]+70))
        pygame.draw.line(self.display, light, (rect.left, rect.top), (rect.right-1, rect.top))
        pygame.draw.line(self.display, light, (rect.left, rect.top), (rect.left, rect.bottom-1))
        dark = (max(0, base_color[0]-70), max(0, base_color[1]-70), max(0, base_color[2]-70))
        pygame.draw.line(self.display, dark, (rect.left, rect.bottom-1), (rect.right-1, rect.bottom-1))
        pygame.draw.line(self.display, dark, (rect.right-1, rect.top), (rect.right-1, rect.bottom-1))

    def draw(self):
        self.display.fill(self.BLACK)
        
        if self.game_state == "START":
            title_text = self.big_font.render("無限落下", False, self.GREEN)
            self.display.blit(title_text, (self.WIDTH//2 - title_text.get_width()//2, self.HEIGHT//2 - 60))
            
            for i, opt in enumerate(self.menu_options):
                color = self.CYAN if i == self.menu_index else self.WHITE
                prefix = "> " if i == self.menu_index else "  "
                text = self.font.render(f"{prefix}{opt}", False, color)
                self.display.blit(text, (self.WIDTH//2 - 40, self.HEIGHT//2 + i * 20))

        elif self.game_state == "RANKING":
            title_text = self.big_font.render("ランキング", False, self.GREEN)
            self.display.blit(title_text, (self.WIDTH//2 - title_text.get_width()//2, 20))
            
            self.ranking.sort(reverse=True)
            for i in range(10):
                score_val = self.ranking[i] if i < len(self.ranking) else "---"
                rank_text = self.font.render(f"{i+1:2d}位 {score_val}m", False, self.WHITE)
                self.display.blit(rank_text, (self.WIDTH//2 - 60, 60 + i * 16))
                
            back_text = self.font.render("PUSH SPACE", False, self.CYAN)
            self.display.blit(back_text, (self.WIDTH//2 - back_text.get_width()//2, 280))

        elif self.game_state == "PLAY":
            for p in self.platforms:
                r = p["rect"]
                if p["type"] == "moving": 
                    color = (70, 100, 160)
                elif p["type"] == "trampoline": 
                    color = (180, 80, 30)
                else: 
                    color = (34, 177, 76)
                self.draw_retro_block(r, color)
                
            if self.player_vy > 0.5 and not self.on_ground:
                self.display.blit(self.img_fall, (int(self.player_x), int(self.player_y)))
            elif self.player_vx < 0:
                self.display.blit(self.img_left, (int(self.player_x), int(self.player_y)))
            elif self.player_vx > 0:
                self.display.blit(self.img_right, (int(self.player_x), int(self.player_y)))
            else:
                self.display.blit(self.img_stand, (int(self.player_x), int(self.player_y)))
            
            # iアプリ風のステータスヘッダーバーを描画
            pygame.draw.rect(self.display, (40, 40, 80), (0, 0, self.WIDTH, 18))
            pygame.draw.line(self.display, self.WHITE, (0, 18), (self.WIDTH, 18))
            
            score_text = self.font.render(f"記録:{int(self.score)}m", False, self.WHITE)
            self.display.blit(score_text, (4, 2))
            speed_text = self.font.render(f"速度:{self.scroll_speed:.1f}", False, self.WHITE)
            self.display.blit(speed_text, (self.WIDTH - speed_text.get_width() - 4, 2))
            
        elif self.game_state == "GAMEOVER":
            for p in self.platforms:
                r = p["rect"]
                if p["type"] == "moving": 
                    color = (70, 100, 160)
                elif p["type"] == "trampoline": 
                    color = (180, 80, 30)
                else: 
                    color = (34, 177, 76)
                self.draw_retro_block(r, color)
                
            # ヘッダーは残す
            pygame.draw.rect(self.display, (40, 40, 80), (0, 0, self.WIDTH, 18))
            pygame.draw.line(self.display, self.WHITE, (0, 18), (self.WIDTH, 18))
            
            dialog_w, dialog_h = 160, 90
            dialog_rect = pygame.Rect(self.WIDTH//2 - dialog_w//2, self.HEIGHT//2 - dialog_h//2, dialog_w, dialog_h)
            
            pygame.draw.rect(self.display, (0, 0, 60), dialog_rect)
            pygame.draw.rect(self.display, self.WHITE, dialog_rect, 2)
            pygame.draw.rect(self.display, (150, 150, 200), dialog_rect.inflate(-4, -4), 1)
            
            go_text = self.big_font.render("終了", False, self.WHITE)
            self.display.blit(go_text, (self.WIDTH//2 - go_text.get_width()//2, self.HEIGHT//2 - 30))
            
            score_text = self.font.render(f"記録: {int(self.score)}m", False, self.WHITE)
            self.display.blit(score_text, (self.WIDTH//2 - score_text.get_width()//2, self.HEIGHT//2))
            
            if pygame.time.get_ticks() % 1000 < 500:
                retry_text = self.font.render("PUSH SPACE KEY", False, self.CYAN)
                self.display.blit(retry_text, (self.WIDTH//2 - retry_text.get_width()//2, self.HEIGHT//2 + 25))

        # 最後に小さいSurfaceを引き伸ばしてメイン画面に描画
        scaled = pygame.transform.scale(self.display, (self.WINDOW_W, self.WINDOW_H))
        self.screen.blit(scaled, (0, 0))
        pygame.display.flip()

async def main():
    game = DropManGame()
    await game.run()

if __name__ == "__main__":
    asyncio.run(main())
